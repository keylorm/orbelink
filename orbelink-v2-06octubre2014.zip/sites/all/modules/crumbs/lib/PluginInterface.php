<?php

interface crumbs_PluginInterface {

}
﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'placeholder', 'ku',
{
	placeholder :
	{
		title		: 'خاسیه‌تی شوێن هه‌ڵگر',
		toolbar		: 'درووستکردنی شوێن هه‌ڵگر',
		text		: 'ده‌ق بۆ شوێن هه‌ڵگڕ',
		edit		: 'چاکسازی شوێن هه‌ڵگڕ',
		textMissing	: 'شوێن هه‌ڵگڕ ده‌بێت له‌ده‌ق پێکهاتبێت.'
	}
});
